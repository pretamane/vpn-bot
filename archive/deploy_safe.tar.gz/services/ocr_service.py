import easyocr
import logging
import os
import numpy as np

logger = logging.getLogger(__name__)

class OCRService:
    def __init__(self, languages=['en']):
        self.languages = languages
        self.reader = None

    def _get_reader(self):
        if self.reader is None:
            logger.info("Initializing EasyOCR reader...")
            # gpu=False to be safe on VPS, though True is faster if available
            self.reader = easyocr.Reader(self.languages, gpu=False)
        return self.reader

    def extract_text(self, image_path):
        """
        Extracts text from an image file.
        Returns a list of strings.
        """
        try:
            reader = self._get_reader()
            # detail=0 returns just the text list
            result = reader.readtext(image_path, detail=0)
            return result
        except Exception as e:
            logger.error(f"OCR extraction failed: {e}")
            return []

# Singleton instance
ocr_service = OCRService()
