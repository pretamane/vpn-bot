#!/bin/bash

# Kill existing processes on ports 8000 and 8080 if any
fuser -k 8000/tcp > /dev/null 2>&1
fuser -k 8080/tcp > /dev/null 2>&1

echo "Starting Developer Tools..."

# Start FastAPI Server
echo "[+] Starting API Server on http://localhost:8000/docs"
uvicorn src.api.server:app --host 0.0.0.0 --port 8000 --reload &
API_PID=$!

# Start SQLite Web
echo "[+] Starting Database Viewer on http://localhost:8080"
sqlite_web src/db/vpn_bot.db --port 8080 --no-browser --host 0.0.0.0 &
DB_PID=$!

echo "Tools running. Press Ctrl+C to stop."

# Wait for user to exit
trap "kill $API_PID $DB_PID; exit" SIGINT
wait
